package com.peisia.board;

import java.util.ArrayList;
import java.util.Scanner;

// ctrl + shift + f = 줄맞춤

public class Main {

	public static void main(String[] args) {
		ArrayList<Post> posts = new ArrayList<>();
		posts.add(new Post("테스트1", "테스트2~~", "abc", 1));
		posts.add(new Post("테스트2", "테스트3~~", "abc", 2));
		posts.add(new Post("테스트3", "테스트4~~", "abc", 3));

		Scanner sc = new Scanner(System.in);

		loop: while (true) {
			System.out.println("================ xxx 게시판 =======================");
			System.out.println("[1:글 쓰기,2:글 리스트, 3:글 읽기,4:글 삭제,5:글 수정,e:끝내기]");
			String cmd = sc.next();
			switch (cmd) {
			case "1":
				System.out.println("==========글 쓰기==========");
				System.out.println("글 제목을 입력해주세요");
				String title = sc.next();
				System.out.println("글 내용을 입력해주세요");
				String content = sc.next();
				System.out.println("ID를 입력해주세요");
				String id = sc.next();
				System.out.println("no를 입력해주세요");
				int no = sc.nextInt();
				posts.add(new Post(title, content, id, no));

				break;
			case "2":
				System.out.println("=========글 리스트========");
				for (int i = 0; i < posts.size(); i++) {
					System.out.print(posts.get(i).no);
					System.out.print("  ");
					System.out.print(posts.get(i).title);
					System.out.print("  ");
					System.out.print(posts.get(i).content);
					System.out.print("  ");
					System.out.print(posts.get(i).id);
					System.out.println();
				}
				break;
			case "3":
				System.out.println("========글 읽기=========");
				System.out.println("읽을 글 번호 입력");
				int readNo = sc.nextInt();
				for (int i = 0; i < posts.size(); i++) {
					if (posts.get(i).no == readNo) {
						System.out.println("===================");
						System.out.println("작성자 id:" + posts.get(i).id);
						System.out.println("===================");
						System.out.println("글제목:" + posts.get(i).title);
						System.out.println("===================");
						System.out.println("글내용:" + posts.get(i).content);
						System.out.println("===================");

					}

				}
				break;
			case "4":
				System.out.println("=========글 삭제=========");
				System.out.println("삭제할 글 번호 입력");
				int delNo = sc.nextInt();
				for (int i = 0; i < posts.size(); i++) {
					if (posts.get(i).no == delNo) {
						System.out.println(posts.get(i).no + "번 글이 삭제되었습니다.");
						posts.remove(i);
					}
				}
				break;
			case "5":

				System.out.println("=========글 수정========");
				System.out.println("수정할 글 번호 입력");
				int reNo = sc.nextInt();
				for (int i = 0; i < posts.size(); i++) {
					if (posts.get(i).no == reNo) {

						System.out.println("수정할 id를 입력해주세요");
						String newId = sc.next();
						System.out.println("수정할 글제목을 입력해주세요");
						String newTitle = sc.next();
						System.out.println("수정할 글내용을 입력해주세요");
						String newContent = sc.next();
						
						posts.get(i).id = newId;
						posts.get(i).title = newTitle;
						posts.get(i).content = newContent;

					}

				}
				break;
				
				
				
				

			case "e":
				System.out.println("프로그램 종료");
				break loop;

			}

		}

	}

}


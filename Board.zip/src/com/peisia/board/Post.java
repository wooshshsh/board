package com.peisia.board;

public class Post {
	String title;
	String content;
	String id;
	int no;
	
	
	
	
	public Post(String title, String content, String id, int no) {
		this.title = title;
		this.content = content;
		this.id = id;
		this.no = no;
	}

}
